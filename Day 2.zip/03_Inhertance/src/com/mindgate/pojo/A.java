package com.mindgate.pojo;

public class A {
	public A() {
		System.out.println("hi");
	}

	public A(int x) {
		System.out.println("hi" + x);
	}
}
