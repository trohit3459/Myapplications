package com.mindgate.pojo;

public class C {
	public static void main(String[] args) {
		B b = new B(10);

	}
}
