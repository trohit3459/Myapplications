package com.mindgate.service;

public interface Notification {
	public void sendNotification(String to, String message);
}
