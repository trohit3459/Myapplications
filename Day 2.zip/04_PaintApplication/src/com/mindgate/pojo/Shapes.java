package com.mindgate.pojo;

public class Shapes {
	public void draw() {
		System.out.println("this is draw()");
	}
}
