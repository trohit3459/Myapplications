package com.mindgate.pojo;

public class Square extends Shapes {
	@Override
	public void draw() {
		System.out.println("Drawing Square");
	}
}
