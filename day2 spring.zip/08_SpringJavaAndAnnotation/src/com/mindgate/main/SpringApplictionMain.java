package com.mindgate.main;

import java.time.LocalDate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindgate.config.ApplicationConfig;
import com.mindgate.pojo.FinancialYearDetails;
import com.mindgate.pojo.MonthDetails;

public class SpringApplictionMain {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		FinancialYearDetails financialYearDetails = applicationContext.getBean("financialYearDetails",
				FinancialYearDetails.class);
		financialYearDetails.setYearId(101);

		financialYearDetails.setYearStartDate(LocalDate.of(2022, 11, 23));
		financialYearDetails.setYearEndDate(LocalDate.of(3467, 10, 11));
		System.out.println(financialYearDetails);

		MonthDetails monthDetails = applicationContext.getBean("monthDetails", MonthDetails.class);
		monthDetails.setFinancialYearDetails(financialYearDetails);
		System.out.println(monthDetails);
	}
}
