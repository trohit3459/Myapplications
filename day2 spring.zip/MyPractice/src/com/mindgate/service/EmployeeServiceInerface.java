package com.mindgate.service;

import com.mindgate.pojo.Employee;

public interface EmployeeServiceInerface {
	boolean insert(Employee employee);

}
