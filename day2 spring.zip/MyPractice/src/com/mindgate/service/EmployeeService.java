package com.mindgate.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.dao.EmployeeDAOInterface;
import com.mindgate.pojo.Employee;

@Service("employeeService")
public class EmployeeService implements EmployeeServiceInerface {

	@Autowired
	EmployeeServiceInerface employeeServiceInerface;

	public boolean insert(Employee employee) {
		employeeServiceInerface.insert(employee);
		return false;
	}

}
