package com.mindgate.main;

import com.mindgate.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee employee = new Employee();
		
	}

}
