package com.mindgate.dao;

import org.springframework.stereotype.Repository;

import com.mindgate.pojo.Employee;

@Repository("employeeDAO")
public class EmployeeDAO implements EmployeeDAOInterface {
	@Override
	public boolean insert(Employee employee) {

		return false;
	}
}
