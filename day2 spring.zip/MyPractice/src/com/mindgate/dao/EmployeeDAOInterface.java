package com.mindgate.dao;

import com.mindgate.pojo.Employee;

public interface EmployeeDAOInterface {
	boolean insert(Employee employee);	
}
