package com.mindgate.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.mindgate.pojo.Address;
import com.mindgate.pojo.Employee;

public class AddressMain {
	
	public static void main(String[] args) {
		System.out.println("main starts");
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
		// Address address = (Address)applicationContext.getBean("address");
//		Address address = applicationContext.getBean("address", Address.class);
//		System.out.println(address);
		Employee employee = applicationContext.getBean("employee", Employee.class);
		System.out.println(employee);
		System.out.println("main ends");
	}
}

