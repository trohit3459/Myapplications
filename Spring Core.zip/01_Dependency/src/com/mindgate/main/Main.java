package com.mindgate.main;

import com.mindgate.pojo.Address;
import com.mindgate.pojo.Employee;

public class Main {
	public static void main(String[] args) {
		Address address = new Address(111, "Kalyan shill Road", "Dombivli", "Maharashrat");
		Employee employee = new Employee(101, "Rohit Thakur", 1000, address);
		
		System.out.println(employee);
		
	}
}
