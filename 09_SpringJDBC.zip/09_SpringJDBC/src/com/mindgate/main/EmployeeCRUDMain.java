package com.mindgate.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mindgate.config.ApplicationConfig;
import com.mindgate.pojo.Employee;
import com.mindgate.service.EmployeeService;
import com.mindgate.service.EmployeeServiceInerface;

public class EmployeeCRUDMain {
	public static void main(String[] args) {
		Employee employee = new Employee(1, "xyz", 100);
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		EmployeeServiceInerface employeeServiceInerface = applicationContext.getBean("employeeService",
				EmployeeService.class);

//		boolean result = employeeServiceInerface.addNewEmployee(employee);
//		if (result) {
//			System.out.println("Employee added sucessfully");
//		} else {
//			System.out.println("Failed to add employee");
//		}
		List<Employee> allEmployees = employeeServiceInerface.getAllEmployees();
		for (Employee emp : allEmployees) {
			System.out.println(emp);
		}
//		System.out.println("-".repeat(50));
//
//		Employee e = employeeServiceInerface.getEmployeeByEmployeeId(3);
//		System.out.println(e);

//		Employee emp = new Employee(25, "Spring JDBC", 2000);
//		boolean result = employeeServiceInerface.updateEmployee(employee);
//		if(result) {
//			System.out.println("updated sucess fully");
//		}
//		else {
//			System.out.println("not updated");
//		}

		boolean result = employeeServiceInerface.deleteEmployeeByEmployeeId(41);
		if (result) {
			System.out.println("deleted sucess fully");
		} else {
			System.out.println("not deleted");
		}

	}

}
